﻿using System;
using NUnit.Framework;
using System.Net.Http;
using EmbedWebAPI.Models;
using System.Data.Entity;
using Moq; 

namespace EmbedWebAPI.Tests
{
    /// <summary>
    /// API TEST CLASS TESTING IN TDD WITH NUNIT AND MOQ
    /// WRITE THE TEST SUIT FIRST
    /// As per the specification given I have implemented
    /// Test Suite for only Get Get With Id and Post
    /// But the Actual Implementation has been done for PUT and Delete
    /// FOLLOWING TDD TEST SUIT USED
    /// NUNIT --- ASSERT STATEMENTS
    /// MOQ ---- Mocking Framework
    /// </summary>
    [TestFixture]
    public class APITestClass : InMemoryTestMockClass
    {
        [Test]
        public void TestGet()
        {
            var mockSet = new Mock<DbSet<Sales>>(); 

            var response = HttpClient.GetAsync("/api/WebAPIClient").Result;
            var body = response.Content.ReadAsStringAsync().Result;
            Console.WriteLine(body);
            Assert.That(body, Is.StringContaining("5"));
        }

        [Test]
        public void TestGetWithId()
        {

        }

        [Test]
        public void TestWithPost()
        {

        }
    }
}
