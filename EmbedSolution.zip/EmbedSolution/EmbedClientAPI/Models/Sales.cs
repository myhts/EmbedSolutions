﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmbedWebAPI.Models
{
    public class Sales
    {
        public int Id { get; set; }
        public DateTime? TimeStamp { get; set; }
        public String LocationName { get; set; }
        public String SalesPersonName { get; set; }
        public double TotalSaleAmount { get; set; }
        public String Currency { get; set; }
        public String SaleInvoiceNumber { get; set; }
        //Lazy Loading For The Navigation Property
        private ICollection<Products> products;

        public virtual ICollection<Products> Products
        {
            get { return products; }
            set { products = value; }
        }
        

        public Sales()
        {
            products = new List<Products>();
        }
    }
}