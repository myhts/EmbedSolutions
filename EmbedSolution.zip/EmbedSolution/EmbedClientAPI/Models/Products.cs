﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmbedWebAPI.Models
{
    public class Products
    {
        public int Id { get; set; }
        public String Name { get; set; }
        public int Quantity { get; set; }
        public double SaleAmount { get; set; }
        //Navigation Property
        public Sales Sales { get; set; }
        //Foreign Key
        public int SalesId { get; set; }
    }
}
