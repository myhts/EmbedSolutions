﻿using EmbedWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmbedClientAPI.Models
{
    public class SalesViewModel
    {
        //This can be later made into loosely coupled DTO module currently its tightly coupled and share same model view as of the WebAPI data model
        public IEnumerable<Sales> Sales { get; set; }
        public IEnumerable<Products> Products { get; set; }

        public SalesViewModel()
        {
            Sales = new List<Sales>();
            Products = new List<Products>();
        }
    }
}