﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace EmbedClientAPI.Helpers
{
    /// <summary>
    /// 
    /// </summary>
    public class SalesTrackerHTTPClient
    {
        public static HttpClient GetClient()
        {

            HttpClient client = new HttpClient();
            //change the url here to point to the Client API Url
            //URL LOCATION will be stored as constant string 
            client.BaseAddress = new Uri(AZURE_URL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            return client;
        }

        //by default uses localy deployed AZURE_URL
        public const string AZURE_URL = "http://embedwebapi.azurewebsites.net/";
        //please specify the URL location for the client api
        public const string EMBED_WEB_API_URL = "";
    }
}