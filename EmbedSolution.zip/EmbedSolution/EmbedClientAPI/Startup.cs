﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(EmbedClientAPI.Startup))]
namespace EmbedClientAPI
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
