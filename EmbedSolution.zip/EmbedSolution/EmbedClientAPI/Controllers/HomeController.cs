﻿using EmbedClientAPI.Helpers;
using EmbedClientAPI.Models;
using EmbedWebAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace EmbedClientAPI.Controllers
{
    /// <summary>
    /// Will be the HomeController that will be consuming the API calls
    /// </summary>
    public class HomeController : Controller
    {
        /// <summary>
        /// Default Entry of the method will be in the index class
        /// </summary>
        /// <returns></returns>
        public async Task<ActionResult> Index()
        {
            //call the client via the helper
            var client = SalesTrackerHTTPClient.GetClient();

            //get the response from the client and display every thing
            HttpResponseMessage response = await client.GetAsync("api/WebAPIClient/");

            var salesViewModel = new SalesViewModel();
            //
            if (response.IsSuccessStatusCode)
            {
                //deserialize it and get the Model Data in the SalesViewModel form
                String content = await response.Content.ReadAsStringAsync();
                var viewModel = JsonConvert.DeserializeObject<IEnumerable<Sales>>(content);
                salesViewModel.Sales = viewModel;
                return View(salesViewModel);
            }
            else
            {
                //we dont want the user to know the problem log the data for now use CW
                Console.WriteLine(response.StatusCode);
                return Content("An error occurred: " + response);
            }

        }

        // GET: Default/Details/5
        public async Task<ActionResult> Details(int id)
        {
            var client = SalesTrackerHTTPClient.GetClient();

            HttpResponseMessage response = await client.GetAsync("api/WebAPIClient/" + id);

            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                var model = JsonConvert.DeserializeObject<Sales>(content);
                return View(model.Products.FirstOrDefault());
            }

            return Content("An error occurred.");
        }

        // GET: Default/Create
        public ActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SaveProduct(Products product)
        {
            try
            {
                var client = SalesTrackerHTTPClient.GetClient();

                Sales sales = product.Sales;

                // serialize & PUT
                var serializedItemToUpdate = JsonConvert.SerializeObject(sales);

                var response = await client.PutAsync("api/WebAPIClient/" + sales.Id,
                    new StringContent(serializedItemToUpdate,
                    System.Text.Encoding.Unicode, "application/json"));

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return Content("An error occurred");
                }

            }
            catch
            {
                return Content("An error occurred");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Save(Sales sales)
        {
            try
            {
                var client = SalesTrackerHTTPClient.GetClient();

                // serialize & PUT
                var serializedItemToUpdate = JsonConvert.SerializeObject(sales);

                var response = await client.PutAsync("api/WebAPIClient/" + sales.Id,
                    new StringContent(serializedItemToUpdate,
                    System.Text.Encoding.Unicode, "application/json"));

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return Content("An error occurred");
                }

            }
            catch
            {
                return Content("An error occurred");
            }
        }
        // POST: Default/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Sales sales)
        {
            try
            {
                //call the client via the helper
                var client = SalesTrackerHTTPClient.GetClient();

                var serializedItemToCreate = JsonConvert.SerializeObject(sales);

                var response = await client.PostAsync("api/WebAPIClient/",
                    new StringContent(serializedItemToCreate,
                        System.Text.Encoding.Unicode,
                        "application/json"));

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return Content("An error occurred.");
                }
            }
            catch
            {
                return Content("An error occurred.");
            }
        }

        // GET: Default/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            var client = SalesTrackerHTTPClient.GetClient();

            HttpResponseMessage response = await client.GetAsync("api/WebAPIClient/" + id);

            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                var model = JsonConvert.DeserializeObject<Sales>(content);
                return View(model);
            }

            return Content("An error occurred.");
        }

        public ActionResult GetProductEditor()
        {
            return PartialView("Shared/_ProductCreate", new Products());
        }
    }
}