﻿using EmbedWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmbedWebAPI.Repository
{
    /// <summary>
    /// This follows repository pattern
    /// This will implement the ISalesRepository Interface
    /// Basically all the get put post delete operations that will be performed on DB
    /// Will be used by this Repository Pattern class object
    /// Follows Single Responsibility pattern that will be responsible for db operations
    /// </summary>
    public interface ISalesRepository
    {
        RepositoryActionResult<Sales> DeleteSales(int id);

        Sales GetSales(int id);

        System.Linq.IQueryable<Sales> GetSales();

        RepositoryActionResult<Sales> InsertSales(Sales e);

        RepositoryActionResult<Sales> UpdateSales(Sales e);

    }
}