﻿using EmbedWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace EmbedWebAPI.Repository
{
    /// <summary>
    /// This follows repository pattern
    /// This will implement the ISalesRepository Interface
    /// Basically all the get put post delete operations that will be performed on DB
    /// Will be used by this Repository Pattern class object
    /// Follows Single Responsibility pattern that will be responsible for db operations
    /// </summary>
    public class SalesRepository : ISalesRepository
    {

        SalesModelContext _ctx;
        /// <summary>
        /// Default constructor which will have the SalesModelContext ctx object initialized
        /// </summary>
        public SalesRepository(SalesModelContext ctx)
        {
            _ctx = ctx;
        }
        /// <summary>
        /// Delete Individual Sales Item by its Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public RepositoryActionResult<Models.Sales> DeleteSales(int id)
        {
            try
            {
                var exp = _ctx.Sales.Where(e => e.Id == id).FirstOrDefault();
                if (exp != null)
                {
                    _ctx.Sales.Remove(exp);
                    _ctx.SaveChanges();
                    return new RepositoryActionResult<Sales>(null, RepositoryActionStatus.Deleted);
                }
                return new RepositoryActionResult<Sales>(null, RepositoryActionStatus.NotFound);
            }
            catch (Exception ex)
            {
                return new RepositoryActionResult<Sales>(null, RepositoryActionStatus.Error, ex);
            }
        }

        /// <summary>
        /// Get the sales item by its Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Models.Sales GetSales(int id)
        {
            return _ctx.Sales.FirstOrDefault(e => e.Id == id);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<Models.Sales> GetSales()
        {
            return _ctx.Sales;
        }

        /// <summary>
        /// Insert the sales item by the Sales object
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public RepositoryActionResult<Models.Sales> InsertSales(Models.Sales e)
        {
            try
            {
                _ctx.Sales.Add(e);
                var result = _ctx.SaveChanges();
                if (result > 0)
                {
                    return new RepositoryActionResult<Sales>(e, RepositoryActionStatus.Created);
                }
                else
                {
                    return new RepositoryActionResult<Sales>(e, RepositoryActionStatus.NothingModified, null);
                }

            }
            catch (Exception ex)
            {
                return new RepositoryActionResult<Sales>(null, RepositoryActionStatus.Error, ex);
            }
        }

        /// <summary>
        /// Update the sales item
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public RepositoryActionResult<Models.Sales> UpdateSales(Models.Sales e)
        {
            try
            {

                // you can only update when an expense already exists for this id

                var existingExpense = _ctx.Sales.FirstOrDefault(exp => exp.Id == e.Id);

                if (existingExpense == null)
                {
                    return new RepositoryActionResult<Sales>(e, RepositoryActionStatus.NotFound);
                }

                // change the original entity status to detached; otherwise, we get an error on attach
                // as the entity is already in the dbSet

                // set original entity state to detached
                _ctx.Entry(existingExpense).State = EntityState.Detached;

                // attach & save
                _ctx.Sales.Attach(e);

                // set the updated entity state to modified, so it gets updated.
                _ctx.Entry(e).State = EntityState.Modified;


                var result = _ctx.SaveChanges();
                if (result > 0)
                {
                    return new RepositoryActionResult<Sales>(e, RepositoryActionStatus.Updated);
                }
                else
                {
                    return new RepositoryActionResult<Sales>(e, RepositoryActionStatus.NothingModified, null);
                }
            }
            catch (Exception ex)
            {
                return new RepositoryActionResult<Sales>(null, RepositoryActionStatus.Error, ex);
            }
        }
    }
}