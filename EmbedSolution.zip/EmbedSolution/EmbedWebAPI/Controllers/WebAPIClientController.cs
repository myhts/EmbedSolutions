﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmbedWebAPI.Models;
using EmbedWebAPI.Repository;

namespace EmbedWebAPI.Controllers
{
    public class WebAPIClientController : ApiController
    {
        //Getting the repository object in actual application we woud use DI or IOC to get it injected here
        ISalesRepository _repository;

        //default constructor which will lead way to the DI or IOC of DBContext Value in Realtime
        public WebAPIClientController()
        {
            _repository = new SalesRepository(new SalesModelContext());
        }


        /// <summary>
        /// Get Sales data
        /// </summary>
        /// <returns></returns>
        public IHttpActionResult Get()
        {
            var sales = _repository.GetSales();

            return Ok(sales.ToList());
        }

        /// <summary>
        /// Get Sales data by the id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult Get(int id)
        {
            try
            {
                var sales = _repository.GetSales(id);

                if (sales == null)
                {
                    return NotFound();
                }
                else
                {
                    return Ok(sales);
                }
            }
            catch (Exception)
            {
                
                return InternalServerError();
            }
        }

        /// <summary>
        /// Post the Sales data
        /// </summary>
        /// <param name="sales"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult Post([FromBody]Models.Sales sales)
        {
            try
            {
                if (sales == null)
                {
                    return BadRequest();
                }

                var result = _repository.InsertSales(sales);
             
                if (result.Status == RepositoryActionStatus.Created)
                {
                    var newSales = _repository.GetSales(sales.Id);

                    return Created(Request.RequestUri + "/" + newSales.Id, newSales);
                }

                return BadRequest();

            }
            catch (Exception)
            {
                return InternalServerError();
            }
        }

        /// <summary>
        /// Update the sales data
        /// </summary>
        /// <param name="id"></param>
        /// <param name="sales"></param>
        /// <returns></returns>
        public IHttpActionResult Put(int id, [FromBody]Models.Sales sales)
        {
            try
            {
                if (sales == null)
                {
                    return BadRequest();
                }

                var result = _repository.UpdateSales(sales);

                if (result.Status == RepositoryActionStatus.Updated)
                {
                    var newSales = _repository.GetSales(sales.Id);

                    return Ok(newSales);
                }
                else if (result.Status == RepositoryActionStatus.NotFound)
                {
                    return NotFound();
                }
                return BadRequest();

            }
            catch (Exception)
            {
                return InternalServerError();
            }
        }

        /// <summary>
        /// Delete the sales data
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult Delete(int id)
        {
            try
            {

                var result = _repository.DeleteSales(id);

                if (result.Status == RepositoryActionStatus.Deleted)
                {
                    return StatusCode(HttpStatusCode.NoContent);
                }
                else if (result.Status == RepositoryActionStatus.NotFound)
                {
                    return NotFound();
                }

                return BadRequest();
            }
            catch (Exception)
            {
                return InternalServerError();
            }
        }
    }
}
