﻿using EmbedWebAPI;
using EmbedWebAPI.Migrations;
using EmbedWebAPI.Models;
using Microsoft.Owin;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Routing;

namespace EmbedWebAPI
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            //USING OWIN AS STARTUP FOR MORE STRICT PIPELINING AND CONTROL COMMENTING BELOW FOR NOW
            //JSON FORMATTING AND RESPONSE RESOLVER
            //GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            //GlobalConfiguration.Configuration.Formatters.Remove(GlobalConfiguration.Configuration.Formatters.XmlFormatter);
            //GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.Formatting
            //    = Newtonsoft.Json.Formatting.Indented;
            //GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.ContractResolver
            //    = new CamelCasePropertyNamesContractResolver();

            //GlobalConfiguration.Configure(WebApiConfig.Register);
            //Database.SetInitializer(new MigrateDatabaseToLatestVersion<SalesModelContext, Configuration>());
        }
    }
}
