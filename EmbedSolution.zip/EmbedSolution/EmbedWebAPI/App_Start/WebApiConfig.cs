﻿using EmbedWebAPI.Migrations;
using EmbedWebAPI.Models;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net.Http.Headers;
using System.Web.Http;

namespace EmbedWebAPI
{
    public static class WebApiConfig
    {

        public static HttpConfiguration Register()
        {
            // Web API configuration and services
            var config = new HttpConfiguration();

            // Web API routes
            config.MapHttpAttributeRoutes();

            //Giving our default routes here
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //config.Formatters.XmlFormatter.SupportedMediaTypes.Clear();

            //config.Formatters.JsonFormatter.SupportedMediaTypes.Add(
            //    new MediaTypeHeaderValue("application/json-patch+json"));

            //config.Formatters.JsonFormatter.SerializerSettings.Formatting
            //    = Newtonsoft.Json.Formatting.Indented;

            //config.Formatters.JsonFormatter.SerializerSettings.ContractResolver
            //    = new CamelCasePropertyNamesContractResolver();
            config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            config.Formatters.Remove(GlobalConfiguration.Configuration.Formatters.XmlFormatter);
            config.Formatters.JsonFormatter.SerializerSettings.Formatting
                = Newtonsoft.Json.Formatting.Indented;
            config.Formatters.JsonFormatter.SerializerSettings.ContractResolver
                = new CamelCasePropertyNamesContractResolver();

            Database.SetInitializer(new MigrateDatabaseToLatestVersion<SalesModelContext, Configuration>());

            return config;

        }
    }
}
